import { createClient } from '@base44/sdk';

const appId = import.meta.env.VITE_BASE44_APP_ID || '6abe7886e3abdf46e56cb091';

const offlineDb = {
  auth: {
    isAuthenticated: async () => !!localStorage.getItem('bodo-auth-user'),
    me: async () => {
      try { return JSON.parse(localStorage.getItem('bodo-auth-user') || 'null'); } catch { return null; }
    },
    loginViaEmailPassword: async () => { throw new Error('لا يمكن تسجيل الدخول بدون اتصال بالإنترنت.'); },
    loginWithProvider: () => { throw new Error('تسجيل الدخول يحتاج اتصالاً بالإنترنت.'); },
    logout: () => localStorage.removeItem('bodo-auth-user'),
    redirectToLogin: (returnTo = '/') => { window.location.href = `/login?returnTo=${encodeURIComponent(returnTo)}`; },
  },
  app: {
    getPublicSettings: async () => ({ public_settings: {} }),
  },
  entities: new Proxy({}, {
    get: () => ({
      list: async () => [],
      filter: async () => [],
      get: async () => null,
      create: async () => ({}),
      update: async () => ({}),
      delete: async () => ({}),
    }),
  }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } },
};

// In the Base44-hosted app the platform can provide the client globally.
// In the standalone APK/web build we create it from VITE_BASE44_APP_ID.
export const db = globalThis.__B44_DB__ || (appId ? createClient({ appId }) : offlineDb);
export const base44 = db;
export default db;
