import Icon from './Icon';

export default function Sidebar({active, setActive, profile, students, onSettings, showToast}) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark"><span></span><span></span><span></span></div>
        <div><strong>بودو</strong><small>مساعدك الصفّي</small></div>
      </div>
      <div className="profile-mini">
        <div className="avatar">س</div>
        <div><b>{profile.teacher}</b><small>{profile.schoolName}</small></div>
        <Icon name="dots"/>
      </div>
      <nav className="nav">
        <div className="nav-label">القائمة الرئيسية</div>
        <button className={active==='overview'?'active':''} onClick={()=>setActive('overview')}><Icon name="home"/>نظرة عامة</button>
        <button className={active==='seating'?'active':''} onClick={()=>setActive('seating')}><Icon name="grid"/>مخطط الجلوس</button>
        <button className={active==='assessment'?'active':''} onClick={()=>setActive('assessment')}><Icon name="calendar"/>التقويم</button>
        <button className={active==='gradebook'?'active':''} onClick={()=>setActive('gradebook')}><Icon name="gradebook"/>دفتر التنقيط</button>
        <div className="nav-label second">إدارة الصف</div>
        <button onClick={()=>{setActive('overview'); showToast('قائمة التلاميذ جاهزة للإدارة')}}><Icon name="users"/>التلاميذ <em>{students.length}</em></button>
        <button onClick={()=>showToast('إعدادات الصف متاحة قريباً')}><Icon name="book"/>المواد الدراسية</button>
      </nav>
      <div className="sidebar-bottom">
        <button onClick={onSettings}><Icon name="settings"/>الإعدادات</button>
        <div className="help-card">
          <div className="help-dot">?</div>
          <div><b>هل تحتاج مساعدة؟</b><small>دليل الاستخدام السريع</small></div>
          <Icon name="arrow"/>
        </div>
      </div>
    </aside>
  );
}