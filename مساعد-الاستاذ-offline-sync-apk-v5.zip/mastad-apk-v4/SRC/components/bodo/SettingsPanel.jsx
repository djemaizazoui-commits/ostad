import { base44 as db } from "@/api/base44Client";

import { useState } from 'react';
import Icon from './Icon';
import useModalHistory from '@/hooks/use-modal-history';

export default function SettingsPanel({settings, setSettings, onClose}) {
  useModalHistory(true, onClose);
  const update = (key) => setSettings(current => ({...current, [key]: !current[key]}));
  const [deleteStep, setDeleteStep] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  const performDelete = async () => {
    setDeleting(true);
    setDeleteError('');
    try {
      const user = await db.auth.me();
      await db.entities.User.delete(user.id);
      await db.auth.logout();
      window.location.href = '/login';
    } catch (e) {
      setDeleteError('تعذر حذف الحساب — تأكد من صلاحياتك أو تواصل مع الدعم.');
      setDeleting(false);
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal settings-modal" onClick={event=>event.stopPropagation()}>
        <button className="modal-close" onClick={onClose}>×</button>
        <span className="eyebrow">تحسين تجربة العمل</span>
        <h2>إعدادات الجودة</h2>
        <p>فعّل الخيارات التي تساعدك على متابعة الأقسام والتلاميذ بوضوح وسرعة.</p>
        <div className="quality-options">
          <label>
            <span><b>الحفظ التلقائي</b><small>تأكيد التعديلات مباشرة أثناء العمل</small></span>
            <input type="checkbox" checked={settings.autoSave} onChange={()=>update('autoSave')}/>
          </label>
          <label>
            <span><b>تنبيهات التقدم</b><small>إظهار رسائل مختصرة عند حفظ أو تحديث البيانات</small></span>
            <input type="checkbox" checked={settings.progressAlerts} onChange={()=>update('progressAlerts')}/>
          </label>
          <label>
            <span><b>تخطيط مضغوط</b><small>إظهار معلومات أكثر داخل البطاقات</small></span>
            <input type="checkbox" checked={settings.compactLayout} onChange={()=>update('compactLayout')}/>
          </label>
        </div>

        <div className="delete-account-section">
          <div className="delete-account-head">
            <span><b>حذف الحساب</b><small>إزالة حسابك وبياناتك نهائياً من التطبيق</small></span>
            {!deleteStep && <button className="outline-btn danger-btn" onClick={()=>{setDeleteStep(true);setConfirmText('');setDeleteError('');}}><Icon name="close"/> حذف الحساب</button>}
          </div>
          {deleteStep && (
            <div className="delete-confirm-box">
              <p>سيتم حذف حسابك وكل بياناتك نهائياً. لا يمكن التراجع عن هذا الإجراء. اكتب <b>حذف</b> للتأكيد.</p>
              <input autoFocus placeholder="اكتب: حذف" value={confirmText} onChange={e=>setConfirmText(e.target.value)} disabled={deleting}/>
              {deleteError && <p className="delete-error">{deleteError}</p>}
              <div className="delete-confirm-actions">
                <button className="outline-btn" onClick={()=>setDeleteStep(false)} disabled={deleting}>إلغاء</button>
                <button className="primary-btn" style={{background:'#c65f75'}} onClick={performDelete} disabled={deleting||confirmText!=='حذف'}>{deleting?'جارٍ الحذف...':'حذف نهائي'}</button>
              </div>
            </div>
          )}
        </div>

        <button className="primary-btn modal-save" onClick={onClose}><Icon name="check"/> حفظ الإعدادات</button>
      </div>
    </div>
  );
}