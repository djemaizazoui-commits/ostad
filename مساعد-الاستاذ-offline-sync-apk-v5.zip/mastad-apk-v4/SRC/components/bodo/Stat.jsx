import Icon from './Icon';

export default function Stat({label, value, suffix, icon, tone, trend}) {
  return (
    <div className="stat-card">
      <div className={`stat-icon ${tone}`}><Icon name={icon}/></div>
      <div>
        <span>{label}</span>
        <div className="stat-value">{value}<small>{suffix}</small></div>
        <em>{trend}</em>
      </div>
    </div>
  );
}