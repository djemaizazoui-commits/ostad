import Icon from './Icon';
import Stat from './Stat';
import MobileSelect from './MobileSelect';
import useModalHistory from '@/hooks/use-modal-history';

export default function Overview(props){
  const {profile,setProfile,editing,setEditing,students,setActive,showAdd,setShowAdd,newName,setNewName,addStudent,visibleStudents,query,setQuery,showToast,criteria,sections,visibleSections,levels,selectedLevelCodes,setSelectedLevelCodes,beginEditSection,deleteSection,selectedSection,selectedSectionId,setSelectedSectionId,showSections,setShowSections,editingSection,setEditingSection,updateSection,newSection,setNewSection,addSection,importStudents,downloadTemplate,fileInputRef,sectionFileInputRef,pendingSectionStudents,setPendingSectionStudents,importSectionStudents,digitalFileInputRef,importDigitalSections} = props;

  useModalHistory(showAdd, ()=>setShowAdd(false));

  return <div className="page">
    <div className="stats-grid">
      <Stat label="إجمالي التلاميذ" value={students.length} suffix="تلميذ" icon="users" tone="purple" trend="في القسم المحدد"/>
      <Stat label="عدد الأقسام" value={sections.length} suffix="أقسام" icon="book" tone="mint" trend="قابلة للتعديل"/>
      <Stat label="الحضور اليوم" value="92" suffix="%" icon="check" tone="blue" trend="ممتاز"/>
    </div>

    <section className="card sections-manager">
      <div className="card-head">
        <div>
          <span className="eyebrow">إدارة الأقسام</span>
          <h2>الأقسام المسندة إليك</h2>
          <p className="toolbar-sub">اختر قسماً للعمل عليه أو عدّل بياناته كما في إعدادات السنة والمستويات.</p>
        </div>
        <div className="section-head-actions">
          <button className="outline-btn small" onClick={()=>digitalFileInputRef.current?.click()}><Icon name="download"/> تحميل ملف الرقمنة</button>
          <input ref={digitalFileInputRef} type="file" accept=".xlsx,.xls" onChange={importDigitalSections} hidden/>
          <button className="primary-btn small" onClick={()=>setShowSections(!showSections)}><Icon name="plus"/> إضافة قسم</button>
        </div>
      </div>

      <div className="level-filter">
        <div>
          <span className="eyebrow">نطاق العرض</span>
          <b>اختر المستويات لإضافة الأقسام</b>
          <small>{selectedLevelCodes.length===4?'كل المستويات متاحة':`تم اختيار ${selectedLevelCodes.length} مستويات`}</small>
        </div>
        <div className="level-filter-options">
          <button type="button" className={`level-choice ${selectedLevelCodes.length===4?'active':''}`} onClick={()=>setSelectedLevelCodes(levels.map(level=>level.code))}>كل المستويات <span>4</span></button>
          {levels.map(level=>
            <button type="button" key={level.code} className={`level-choice ${selectedLevelCodes.includes(level.code)?'active':''}`} onClick={()=>setSelectedLevelCodes(current=>current.includes(level.code)?current.filter(code=>code!==level.code):[...current,level.code])}>{level.label} <span>{sections.filter(section=>section.level===level.label).length}</span></button>
          )}
        </div>
      </div>

      <div className="section-groups">
        {levels.map(level=>{
          const levelSections=visibleSections.filter(section=>section.level===level.label||section.code?.startsWith(level.code));
          return (
            <div className="level-section-group" key={level.code}>
              <div className="level-group-title">
                <span className="section-icon">{level.code}</span>
                <div><b>{level.label}</b><small>{levelSections.length} أقسام مسندة ومحفوظة</small></div>
              </div>
              <div className="section-tabs">
                {levelSections.length?levelSections.map(section=>
                  <button key={section.id} className={`section-tab ${selectedSectionId===section.id?'active':''}`} onClick={()=>{setSelectedSectionId(section.id);setProfile({...profile,className:section.name,year:section.year,subject:section.subject});}}>
                    <span className="section-icon">{section.name}</span>
                    <span><b>{section.name}</b><small>{section.year}</small></span>
                    <span className="section-edit-icon" title="تعديل القسم" onClick={(event)=>{event.stopPropagation();beginEditSection(section)}}><Icon name="edit"/></span>
                  </button>
                ):<span className="empty-level">لا توجد أقسام في هذا المستوى بعد</span>}
              </div>
            </div>
          );
        })}
      </div>

      {showSections && (
        <div className="section-editor">
          <div className="editor-title">
            <b>{editingSection?'تعديل بيانات القسم':'إضافة قسم جديد'}</b>
            <small>{editingSection?'عدّل المستوى أو السنة أو المادة ثم احفظ':'مثال: الأولى متوسط أو 1AM'}</small>
          </div>
          <div className="section-form simplified-section-form">
            <label>المستوى
              <MobileSelect value={newSection.level} onChange={val=>setNewSection({...newSection,level:val})} label="المستوى">
                {levels.filter(level=>selectedLevelCodes.includes(level.code)).map(level=><option key={level.code}>{level.label}</option>)}
              </MobileSelect>
            </label>
            <label>السنة الدراسية
              <input value={newSection.year} onChange={e=>setNewSection({...newSection,year:e.target.value})} placeholder="2026 / 2027"/>
            </label>
            <label>اسم القسم
              <input value={newSection.name} onChange={e=>setNewSection({...newSection,name:e.target.value})} placeholder="مثال: 1م4 أو 3م5"/>
            </label>
            <div className="section-import-box">
              <button type="button" className="outline-btn" onClick={()=>sectionFileInputRef.current?.click()}><Icon name="download"/> استيراد قائمة XLSX</button>
              <input ref={sectionFileInputRef} type="file" accept=".xlsx,.xls" onChange={importSectionStudents} hidden/>
              <small>{pendingSectionStudents.length?`تم تجهيز ${pendingSectionStudents.length} تلميذاً للحفظ مع القسم`:'اختياري — أضف القائمة قبل حفظ القسم'}</small>
            </div>
            <button className="primary-btn" onClick={addSection}>{editingSection?'حفظ التعديل':'حفظ القسم'}</button>
            {editingSection && <>
              <button className="outline-btn danger-btn" onClick={()=>deleteSection(editingSection)}>حذف القسم</button>
              <button className="outline-btn" onClick={()=>{setEditingSection(null);setShowSections(false);setPendingSectionStudents([]);setNewSection({name:'',code:'',level:'الأولى متوسط',year:'2026 / 2027',subject:'الرياضيات'})}}>إلغاء</button>
            </>}
          </div>
        </div>
      )}

      <div className="assigned-levels-note"><Icon name="check"/> الأقسام الظاهرة هنا هي الأقسام المسندة التي تم حفظها والعمل عليها.</div>
    </section>

    <div className="section-grid">
      <section className="card profile-card">
        <div className="card-head">
          <div><span className="eyebrow">بطاقة الأستاذ</span><h2>معلومات القسم</h2></div>
          <button className="ghost-btn" onClick={()=>setEditing(!editing)}><Icon name="edit"/> {editing?'حفظ':'تعديل'}</button>
        </div>
        {editing?(
          <div className="edit-profile">
            {Object.entries({schoolName:'اسم المتوسطة',year:'السنة الدراسية',teacher:'اسم الأستاذ',subject:'مادة التدريس'}).map(([key,label])=>
              <label key={key}>{label}<input value={profile[key]} onChange={e=>setProfile({...profile,[key]:e.target.value})}/></label>
            )}
          </div>
        ):(
          <div className="profile-content">
            <div className="teacher-portrait"><span>س</span><i>✓</i></div>
            <div className="profile-details">
              <h3>{profile.schoolName}</h3>
              <div className="tag-row"><span>{profile.year}</span><span>{profile.subject}</span></div>
              <div className="detail-line"><span>اسم الأستاذ</span><b>{profile.teacher}</b></div>
            </div>
          </div>
        )}
        <div className="class-progress">
          <div><span>اكتمال إعداد القسم</span><b>75%</b></div>
          <div className="progress"><i style={{width:'75%'}}/></div>
          <small>القسم النشط: {selectedSection?.name} ({selectedSection?.code})</small>
        </div>
      </section>

      <section className="card import-card">
        <div className="card-head">
          <div><span className="eyebrow">استيراد جماعي</span><h2>قائمة التلاميذ من Excel</h2></div>
          <span className="excel-badge">XLSX</span>
        </div>
        <p>ارفع ملف Excel يحتوي على عمود واحد باسم <b>اسم التلميذ</b>. سيتم استبدال قائمة القسم الحالي بالأسماء الموجودة في الملف.</p>
        <div className="import-actions">
          <button className="primary-btn" onClick={()=>fileInputRef.current?.click()}><Icon name="download"/> اختيار ملف XLSX</button>
          <button className="outline-btn" onClick={downloadTemplate}><Icon name="book"/> تنزيل نموذج</button>
          <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={importStudents} hidden/>
        </div>
        <div className="import-hint"><span>1</span> أنشئ ملفاً بعمود «اسم التلميذ»<span>2</span> ارفعه هنا<span>3</span> راجع القائمة في الأسفل</div>
      </section>
    </div>

    <div className="section-grid lower">
      <section className="card students-card">
        <div className="card-head">
          <div><span className="eyebrow">قائمة الصف</span><h2>التلاميذ <small>({students.length})</small></h2></div>
          <button className="primary-btn small" onClick={()=>setShowAdd(true)}><Icon name="plus"/> إضافة تلميذ</button>
        </div>
        <div className="search-box"><Icon name="search"/><input placeholder="ابحث عن تلميذ..." value={query} onChange={e=>setQuery(e.target.value)}/></div>
        <div className="student-list">
          {visibleStudents.slice(0,5).map((s,i)=>
            <div className="student-row" key={s}>
              <div className={`student-avatar a${i}`}>{s[0]}</div>
              <div><b>{s}</b><small>{selectedSection?.name} · تلميذ نشط</small></div>
              <span className="status-pill">منتظم</span>
              <Icon name="dots"/>
            </div>
          )}
          {visibleStudents.length>5 && <button className="show-more" onClick={()=>showToast(`يوجد ${visibleStudents.length-5} تلاميذ آخرين`)}>عرض كل التلاميذ <Icon name="arrow"/></button>}
        </div>
      </section>

      <section className="card criteria-card">
        <div className="card-head">
          <div><span className="eyebrow">آخر تحديث</span><h2>ملخص التقويم</h2></div>
          <button className="link-btn" onClick={()=>setActive('assessment')}>عرض التفاصيل <Icon name="arrow"/></button>
        </div>
        <div className="criteria-list">
          {criteria.slice(0,4).map((c,i)=>
            <div className="criteria-row" key={c.name}>
              <div className={`criterion-icon ${c.color}`}>{c.icon}</div>
              <div className="criterion-label"><b>{c.name}</b><div className="progress thin"><i className={c.color} style={{width:(c.score/c.max*100)+'%'}}/></div></div>
              <strong>{c.score}<small>/{c.max}</small></strong>
            </div>
          )}
        </div>
      </section>
    </div>

    {showAdd && (
      <div className="modal-backdrop" onClick={()=>setShowAdd(false)}>
        <div className="modal" onClick={e=>e.stopPropagation()}>
          <button className="modal-close" onClick={()=>setShowAdd(false)}>×</button>
          <span className="eyebrow">تلميذ جديد</span>
          <h2>إضافة إلى الصف</h2>
          <p>أدخل اسم التلميذ ليظهر في القائمة ومخطط الجلوس.</p>
          <input autoFocus placeholder="مثال: أحمد بن علي" value={newName} onChange={e=>setNewName(e.target.value)} onKeyDown={e=>e.key==='Enter'&&addStudent()}/>
          <button className="primary-btn" onClick={addStudent}>إضافة التلميذ</button>
        </div>
      </div>
    )}
  </div>;
}