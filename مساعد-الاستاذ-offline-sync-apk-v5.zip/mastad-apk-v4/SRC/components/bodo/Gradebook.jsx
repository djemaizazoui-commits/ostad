import Icon from './Icon';

export default function Gradebook(props){
  const {rows,sections,selectedSection,selectedSectionId,setSelectedSectionId,importGradebook,exportGradebookXlsx,exportGradebookWord,printGradebook,syncContinuousAssessment,setGradebookBySection,showToast} = props;
  const update=(index,key,value)=>setGradebookBySection(prev=>({...prev,[selectedSectionId]:rows.map((row,i)=>i===index?{...row,[key]:value}:row)}));

  return <div className="page gradebook-page">
    <section className="card saved-sections-card">
      <div className="saved-sections-title">
        <div><span className="eyebrow">دفتر التنقيط</span><h3>اختر القسم المراد تسجيل نقاطه</h3></div>
        <span className="section-count">{sections.length} أقسام</span>
      </div>
      <div className="saved-sections-list">
        {sections.map(section=>
          <button key={section.id} className={`saved-section ${selectedSectionId===section.id?'active':''}`} onClick={()=>setSelectedSectionId(section.id)}>
            <span className="section-icon">{section.code||'قسم'}</span>
            <span><b>{section.name}</b><small>{section.subject} · {section.year}</small></span>
            <strong>{section.id===selectedSectionId?rows.length:0} تلميذ</strong>
          </button>
        )}
      </div>
    </section>

    <div className="toolbar">
      <div><span className="eyebrow">وثيقة حجز النقاط</span><h2>دفتر تنقيط {selectedSection.name}</h2><p className="toolbar-sub">{selectedSection.subject} · {selectedSection.year} · {rows.length} تلميذاً</p></div>
      <div className="toolbar-actions">
        <label className="outline-btn file-action"><Icon name="download"/> استيراد XLSX<input type="file" accept=".xlsx,.xls" onChange={importGradebook}/></label>
        <button className="outline-btn" onClick={syncContinuousAssessment}><Icon name="calendar"/> حفظ التقويم المستمر</button>
        <button className="outline-btn" onClick={printGradebook}><Icon name="print"/> PDF / طباعة</button>
        <button className="outline-btn" onClick={exportGradebookWord}><Icon name="book"/> Word</button>
        <button className="primary-btn" onClick={exportGradebookXlsx}><Icon name="download"/> XLSX</button>
      </div>
    </div>

    <section className="card gradebook-card">
      <div className="gradebook-heading">
        <div>
          <span className="eyebrow">{selectedSection.name} — سجل الفصل</span>
          <h3>حجز نقاط التلاميذ</h3>
          <p>معدل التقويم المستمر يُحتسب من معايير التقويم /20 ويُحفظ في خانة تقويم النشاطات.</p>
        </div>
        <div className="gradebook-badge">{rows.length} سجل</div>
      </div>
      <div className="gradebook-scroll">
        <table className="gradebook-table">
          <thead>
            <tr><th>م</th><th>رقم التعريف</th><th>اللقب</th><th>الاسم</th><th>تاريخ الميلاد</th><th>تقويم النشاطات /20</th><th>الفرض /20</th><th>الاختبار /20</th><th>التقديرات</th></tr>
          </thead>
          <tbody>
            {rows.length?rows.map((row,index)=>
              <tr key={`${row.nom}-${row.prenom}-${index}`}>
                <td>{index+1}</td>
                {['matricule','nom','prenom','date_n','activity','homework','exam','obs'].map(key=>
                  <td key={key}><input aria-label={key} value={row[key]||''} onChange={e=>update(index,key,e.target.value)} /></td>
                )}
              </tr>
            ):<tr><td colSpan="9" className="gradebook-empty">لا توجد سجلات بعد. استخدم زر استيراد XLSX أو أضف تلاميذ القسم.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>

    <div className="gradebook-note">
      <span>▥</span>
      <p><b>مطابق لدفتر الحجز:</b> رقم التعريف، اللقب، الاسم، تاريخ الميلاد، تقويم النشاطات، الفرض، الاختبار والتقديرات. استخدم «PDF / طباعة» ثم اختر «حفظ كملف PDF».</p>
    </div>
  </div>;
}