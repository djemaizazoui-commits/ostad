export default function Icon({name}) {
  const map = {grid:'▦',home:'⌂',users:'♧',calendar:'▣',book:'▤',gradebook:'▥',settings:'⚙',bell:'♢',search:'⌕',plus:'＋',edit:'✎',download:'↓',print:'▣',dots:'•••',arrow:'↗',check:'✓',close:'×',move:'✣',user:'♙',cloud:'☁',upload:'↑',sun:'☀',moon:'☾'};
  return <span className="icon" aria-hidden="true">{map[name] || name}</span>;
}