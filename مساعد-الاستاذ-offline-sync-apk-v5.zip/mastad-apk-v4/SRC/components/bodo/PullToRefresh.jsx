import { useState, useRef, useEffect } from 'react';

const THRESHOLD = 70;
const MAX_PULL = 100;

/**
 * Native-like pull-to-refresh wrapper. When the user touches and drags
 * downward at the top of the page, an indicator appears; releasing past the
 * threshold triggers `onRefresh` (typically a cloud sync).
 */
export default function PullToRefresh({ onRefresh, children }) {
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startYRef = useRef(0);
  const pullingRef = useRef(false);
  const pullDistanceRef = useRef(0);
  const refreshingRef = useRef(false);
  const onRefreshRef = useRef(onRefresh);
  const containerRef = useRef(null);

  useEffect(() => { onRefreshRef.current = onRefresh; });
  useEffect(() => { refreshingRef.current = refreshing; }, [refreshing]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const handleTouchStart = (e) => {
      if (window.scrollY > 0 || refreshingRef.current) return;
      startYRef.current = e.touches[0].clientY;
      pullingRef.current = true;
    };

    const handleTouchMove = (e) => {
      if (!pullingRef.current || refreshingRef.current) return;
      const delta = e.touches[0].clientY - startYRef.current;
      if (delta > 0 && window.scrollY <= 0) {
        e.preventDefault();
        const dist = Math.min(delta * 0.5, MAX_PULL);
        pullDistanceRef.current = dist;
        setPullDistance(dist);
      }
    };

    const handleTouchEnd = async () => {
      if (!pullingRef.current) return;
      pullingRef.current = false;
      if (pullDistanceRef.current >= THRESHOLD) {
        setRefreshing(true);
        setPullDistance(THRESHOLD);
        try {
          await onRefreshRef.current();
        } finally {
          setRefreshing(false);
          setPullDistance(0);
          pullDistanceRef.current = 0;
        }
      } else {
        setPullDistance(0);
        pullDistanceRef.current = 0;
      }
    };

    el.addEventListener('touchstart', handleTouchStart, { passive: true });
    el.addEventListener('touchmove', handleTouchMove, { passive: false });
    el.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchmove', handleTouchMove);
      el.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  return (
    <div ref={containerRef} className="ptr-wrapper">
      <div className="ptr-indicator" style={{ height: pullDistance }}>
        <div className={`ptr-spinner ${refreshing ? 'spinning' : ''}`}>
          {refreshing ? '↻' : '↓'}
        </div>
      </div>
      {children}
    </div>
  );
}