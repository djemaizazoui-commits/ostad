import { useState } from 'react';
import Icon from './Icon';
import MobileSelect from './MobileSelect';
import useModalHistory from '@/hooks/use-modal-history';
import { criteriaSeed } from '@/lib/bodoData';

export default function Seating(props){
  const {sections,setSelectedSectionId,profile,selectedSection,rows,cols,setRows,setCols,seats,students,seatOrder,setSeatOrder,studentScores,changeStudentScore,showToast,attendanceMode,selectedSectionId,attendanceBySection,toggleAttendance} = props;
  const [moveMode,setMoveMode]=useState(false);
  const [selectedIndex,setSelectedIndex]=useState(null);
  const [assessmentStudent,setAssessmentStudent]=useState(null);
  const [pressTimer,setPressTimer]=useState(null);
  useModalHistory(!!assessmentStudent, ()=>setAssessmentStudent(null));

  const startLongPress=(student,index)=>{ if(!student || attendanceMode)return; const timer=setTimeout(()=>{setAssessmentStudent(student);setSelectedIndex(null);},550); setPressTimer(timer); };
  const endLongPress=()=>{ if(pressTimer){clearTimeout(pressTimer);setPressTimer(null);} };
  const seatClick=(index)=>{
    const student=seats[index];
    if(attendanceMode){ if(student) toggleAttendance(student); return; }
    if(!moveMode){ if(student){setAssessmentStudent(student);} return; }
    if(selectedIndex===null){ if(student){setSelectedIndex(index);showToast(`تم اختيار ${student} — اختر مقعداً آخر للنقل`);} return; }
    if(selectedIndex===index){setSelectedIndex(null);return;}
    const next=[...seatOrder]; [next[selectedIndex],next[index]]=[next[index],next[selectedIndex]]; setSeatOrder(next); setSelectedIndex(null); showToast('تم نقل التلميذ إلى المقعد الجديد');
  };
  const scores=assessmentStudent ? (studentScores[assessmentStudent]||criteriaSeed.map(c=>c.score)) : [];
  const studentTotal=scores.reduce((sum,score)=>sum+score,0);
  const totalMax=criteriaSeed.reduce((sum,criterion)=>sum+criterion.max,0);

  return <div className="page seating-page">
    <div className="seating-print-header">
      <h1>مخطط الجلوس</h1>
      <div className="seating-print-meta">
        <span><b>المتوسطة</b>{profile.schoolName}</span>
        <span><b>القسم</b>{selectedSection.name}</span>
        <span><b>الحجرة</b>حجرة التدريس 01</span>
        <span><b>عدد التلاميذ</b>{students.length}</span>
      </div>
    </div>
    <div className="toolbar">
      <div>
        <span className="eyebrow">تنظيم الصف</span>
        <h2>مخطط الجلوس التفاعلي</h2>
        <p className="toolbar-sub">{attendanceMode?'وضع المناداة مفعّل · اضغط على التلميذ لتسجيل غيابه':moveMode?'وضع النقل مفعّل · اضغط على تلميذ ثم على المقعد الجديد':'اضغط مطولاً على اسم التلميذ لفتح تقويمه الخاص'}</p>
      </div>
      <div className="seating-section-picker">
        <label>القسم</label>
        <MobileSelect value={selectedSection.id} onChange={val=>setSelectedSectionId(Number(val))} label="اختر القسم">
          {sections.map(section=><option key={section.id} value={section.id}>{section.name}</option>)}
        </MobileSelect>
      </div>
      <div className="toolbar-actions">
        <button className={`move-toggle ${moveMode?'active':''}`} onClick={()=>{setMoveMode(!moveMode);setSelectedIndex(null)}}><Icon name="move"/> {moveMode?'إيقاف النقل':'تعديل التجليس'}</button>
        <button className="outline-btn" onClick={()=>window.print()}><Icon name="print"/> طباعة المخطط</button>
        <button className="primary-btn" onClick={()=>showToast('تم حفظ توزيع المقاعد')}><Icon name="check"/> حفظ التغييرات</button>
      </div>
    </div>

    <div className="seating-layout">
      <section className="card seating-card">
        <div className="room-head">
          <div><b>حجرة التدريس 01</b><small>{attendanceMode?'اضغط على أي تلميذ لتسجيل غيابه أو تصحيح حالته':'أيقونة ✣ لتفعيل النقل · ضغط مطول على اسم التلميذ للتقويم'}</small></div>
          <span className="room-status"><i/> نشط الآن</span>
        </div>
        <div className="board">السبورة</div>
        <div className="mobile-scroll-hint">اسحب يميناً ويساراً لرؤية كامل المخطط</div>
        <div className="seating-scroll">
          <div className="seat-grid" style={{gridTemplateColumns:`repeat(${cols}, minmax(120px,1fr))`}}>
            {Array.from({length:rows*cols},(_,deskIndex)=>
              <div className="desk" key={deskIndex}>
                {[deskIndex*2,deskIndex*2+1].map(index=>
                  <div className={`desk-seat-wrap ${selectedIndex===index?'selected-seat':''} ${attendanceBySection[selectedSectionId]?.[seats[index]]==='absent'?'absent-seat-card':''}`} key={index}
                    onClick={()=>seatClick(index)} onPointerDown={()=>startLongPress(seats[index],index)} onPointerUp={endLongPress} onPointerLeave={endLongPress} onContextMenu={e=>e.preventDefault()}>
                    {seats[index]?<>
                      <span className="seat-handle"><Icon name="move"/></span>
                      <span className="seat-name">{seats[index]}</span>
                      {attendanceBySection[selectedSectionId]?.[seats[index]]==='absent' && <span className="attendance-badge">غائب</span>}
                      <span className="seat-hint">{attendanceMode?(attendanceBySection[selectedSectionId]?.[seats[index]]==='absent'?'اضغط للتصحيح':'اضغط لتسجيل غائب'):moveMode?'اختر للنقل':'اضغط مطولاً'}</span>
                    </>:<span className="empty-seat">مقعد شاغر</span>}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
        <div className="room-legend">
          <span><i className="dot green"/> مقعد مشغول</span>
          <span><i className="dot gray"/> مقعد شاغر</span>
          <span><Icon name="move"/> {moveMode?'وضع النقل يعمل':'وضع العرض'}</span>
        </div>
      </section>

      <aside className="card control-card">
        <span className="eyebrow">إعدادات المخطط</span>
        <div className="room-student-count">
          <div><span>عدد التلاميذ في القسم</span><small>العدد الحقيقي للقسم المحدد</small></div>
          <strong>{students.length}</strong>
        </div>
        <h3>حجم الحجرة</h3>
        <div className="control-row">
          <label>عدد الصفوف <b>{rows}</b></label>
          <div className="stepper"><button onClick={()=>setRows(Math.max(1,rows-1))}>−</button><span>{rows}</span><button onClick={()=>setRows(Math.min(6,rows+1))}>＋</button></div>
        </div>
        <div className="control-row">
          <label>عدد الأعمدة <b>{cols}</b></label>
          <div className="stepper"><button onClick={()=>setCols(Math.max(2,cols-1))}>−</button><span>{cols}</span><button onClick={()=>setCols(Math.min(6,cols+1))}>＋</button></div>
        </div>
        <hr/>
        <h3>توزيع سريع</h3>
        <button className={`option-btn ${moveMode?'selected':''}`} onClick={()=>{setMoveMode(current=>!current);setSelectedIndex(null)}}>
          <Icon name="move"/><div><b>{moveMode?'إيقاف تعديل التجليس':'تعديل التجليس'}</b><small>انقل التلاميذ بين المقاعد</small></div>
          <Icon name={moveMode?'check':'arrow'}/>
        </button>
        <button className="option-btn selected"><span>▦</span><div><b>مقاعد مزدوجة</b><small>تلميذان في كل طاولة</small></div><Icon name="check"/></button>
        <button className="option-btn" onClick={()=>{const shuffled=[...seatOrder].sort(()=>Math.random()-.5);setSeatOrder(shuffled);showToast('تم توزيع التلاميذ عشوائياً')}}><span>↔</span><div><b>توزيع عشوائي</b><small>تغيير أماكن التلاميذ</small></div></button>
        <div className="tip"><span>✦</span><p>فعّل «تعديل التجليس» ثم اضغط على تلميذ وبعده على المقعد الجديد لنقله.</p></div>
      </aside>
    </div>

    {assessmentStudent && (
      <div className="modal-backdrop" onClick={()=>setAssessmentStudent(null)}>
        <div className="modal student-assessment" onClick={e=>e.stopPropagation()}>
          <button className="modal-close" onClick={()=>setAssessmentStudent(null)}>×</button>
          <div className="student-modal-head">
            <div className="student-big-avatar">{assessmentStudent[0]}</div>
            <div><span className="eyebrow">التقويم الفردي</span><h2>{assessmentStudent}</h2><p>عدّل نقاط التلميذ بمقدار 0.5 نقطة.</p></div>
          </div>
          <div className="individual-total"><span>مجموع التقويم</span><strong>{studentTotal.toFixed(1)} <small>/ {totalMax}</small></strong></div>
          <div className="personal-criteria">
            {criteriaSeed.map((criterion,i)=>
              <div className="personal-row" key={criterion.name}>
                <div className={`criterion-icon ${criterion.color}`}>{criterion.icon}</div>
                <div><b>{criterion.name}</b><small>من {criterion.max} نقاط</small></div>
                <div className="half-stepper">
                  <button onClick={()=>changeStudentScore(assessmentStudent,i,-0.5)}>−</button>
                  <strong>{scores[i]?.toFixed(1)}</strong>
                  <button onClick={()=>changeStudentScore(assessmentStudent,i,0.5)}>＋</button>
                </div>
              </div>
            )}
          </div>
          <button className="primary-btn modal-save" onClick={()=>{setAssessmentStudent(null);showToast('تم حفظ تقويم التلميذ')}}><Icon name="check"/> حفظ التقويم</button>
        </div>
      </div>
    )}
  </div>;
}