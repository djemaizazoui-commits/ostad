import Icon from './Icon';

export default function Topbar({active, attendanceMode, setAttendanceMode, setActive, showToast, saveSyncFile, importSyncFile, syncFileInputRef, saveLocal, cloudSaving, theme, setTheme}) {
  const titleMap = {overview:'نظرة عامة', seating:'مخطط الجلوس', assessment:'التقويم', gradebook:'دفتر التنقيط'};
  const headingMap = {overview:'صباح الخير، الجمعي 👋', seating:'مخطط الجلوس', assessment:'تقويم التلاميذ', gradebook:'دفتر التنقيط'};
  const subMap = {overview:'إليك ملخص صفك الدراسي لهذا اليوم.', seating:'نظّم مقاعد تلاميذك بسهولة ووضوح.', assessment:'تابع أداء تلاميذك وطوّر عاداتهم اليومية.', gradebook:'سجّل نقاط الفروض والاختبارات واطبع دفتر القسم.'};
  return (
    <header className="topbar">
      <div>
        <div className="breadcrumb">الصفوف <span>/</span> {titleMap[active]}</div>
        <h1>{headingMap[active]}</h1>
        <p>{subMap[active]}</p>
      </div>
      <div className="top-actions">
        <button className="icon-btn theme-toggle" title={theme==='dark'?'الوضع النهاري':'الوضع الليلي'} aria-label="تبديل الوضع الليلي/النهاري" onClick={()=>setTheme(theme==='dark'?'light':'dark')}><Icon name={theme==='dark'?'sun':'moon'}/></button>
        <button className={`icon-btn cloud-save-btn ${cloudSaving?'is-saving':''}`} title="حفظ محلي" aria-label="حفظ التغييرات" onClick={saveLocal}><Icon name="cloud"/></button>
        <button className="icon-btn sync-save-btn" title="حفظ ملف المزامنة" aria-label="حفظ ملف المزامنة" onClick={saveSyncFile}><Icon name="download"/></button>
        <button className="icon-btn sync-load-btn" title="استيراد ملف المزامنة" aria-label="استيراد ملف المزامنة" onClick={()=>syncFileInputRef.current?.click()}><Icon name="upload"/></button>
        <input ref={syncFileInputRef} type="file" accept=".json,application/json" onChange={importSyncFile} hidden/>
        <button className={`icon-btn attendance-trigger ${attendanceMode?'active':''}`} title="المناداة والحضور" aria-label="تفعيل المناداة والحضور" onClick={()=>{setAttendanceMode(current=>!current);setActive('seating');showToast(attendanceMode?'تم إيقاف المناداة':'تم تفعيل المناداة — اضغط على التلميذ لتسجيل غيابه')}}><Icon name="check"/><i></i></button>
        <div className="top-avatar">ج</div>
      </div>
    </header>
  );
}