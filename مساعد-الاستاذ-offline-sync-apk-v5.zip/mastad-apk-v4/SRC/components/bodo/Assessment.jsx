import { useState } from 'react';
import Icon from './Icon';
import useModalHistory from '@/hooks/use-modal-history';

export default function Assessment(props){
  const {criteria,setCriteria,changeScore,changeStudentScore,exportXlsx,exportWord,printAssessment,showToast,students,selectedSection,sections,selectedSectionId,setSelectedSectionId,studentScores,studentsBySection} = props;
  const [editing,setEditing]=useState(false);
  const [studentEditor,setStudentEditor]=useState(null);
  const [draft,setDraft]=useState(criteria);
  useModalHistory(editing, ()=>setEditing(false));
  useModalHistory(!!studentEditor, ()=>setStudentEditor(null));
  const total=criteria.reduce((sum,item)=>sum+item.score,0);
  const maxTotal=criteria.reduce((sum,item)=>sum+item.max,0);
  const openEditor=()=>{setDraft(criteria.map(item=>({...item})));setEditing(true)};
  const studentValues=studentEditor ? (studentScores[studentEditor]||criteria.map(item=>item.score)) : [];
  const studentTotal=studentEditor ? studentValues.reduce((sum,value)=>sum+Number(value||0),0) : 0;
  const saveEditor=()=>{const sum=draft.reduce((total,item)=>total+Number(item.max||0),0); if(sum!==20){showToast(`يجب أن يساوي مجموع الحدود 20 نقطة، المجموع الحالي ${sum}`);return;} setCriteria(draft.map(item=>({...item,max:Number(item.max),score:Math.min(item.score,Number(item.max))})));setEditing(false);showToast('تم حفظ تعديلات المعايير');};

  return <div className="page">
    <section className="card saved-sections-card">
      <div className="saved-sections-title">
        <div><span className="eyebrow">الأقسام المحفوظة</span><h3>اختر القسم لمعاينة تقويمه</h3></div>
        <span className="section-count">{sections.length} أقسام</span>
      </div>
      <div className="saved-sections-list">
        {sections.map(section=>
          <button key={section.id} className={`saved-section ${selectedSectionId===section.id?'active':''}`} onClick={()=>setSelectedSectionId(section.id)}>
            <span className="section-icon">{section.code||'قسم'}</span>
            <span><b>{section.name}</b><small>{section.subject} · {section.year}</small></span>
            <strong>{(studentsBySection[section.id]||[]).length} تلميذ</strong>
          </button>
        )}
      </div>
    </section>

    <div className="toolbar">
      <div><span className="eyebrow">متابعة الأداء</span><h2>التقويم الأسبوعي</h2><p className="toolbar-sub">{selectedSection.name} · الأسبوع الثالث · {students.length} تلميذاً</p></div>
      <div className="toolbar-actions">
        <button className="outline-btn" onClick={printAssessment}><Icon name="print"/> PDF / طباعة</button>
        <button className="outline-btn" onClick={exportWord}><Icon name="book"/> Word</button>
        <button className="outline-btn" onClick={exportXlsx}><Icon name="download"/> XLSX</button>
        <button className="primary-btn" onClick={()=>showToast('تم حفظ التقييمات')}><Icon name="check"/> حفظ التقييم</button>
      </div>
    </div>

    <div className="assessment-summary">
      <div className="summary-score">
        <div className="score-ring"><b>{total.toFixed(1).replace('.0','')}</b><span>/{maxTotal}</span></div>
        <div><b>مجموع القسم</b><small>من {maxTotal} نقطة</small></div>
      </div>
      <div className="summary-stat"><span>عدد المعايير</span><b>{criteria.length} معايير</b><small>قابلة للتعديل</small></div>
      <div className="summary-stat"><span>النظام</span><b>20 / 20</b><small>نصف نقطة</small></div>
      <div className="summary-stat"><span>آخر حفظ</span><b>اليوم، 09:42</b><small>محفوظ تلقائياً</small></div>
    </div>

    <section className="card assessment-card">
      <div className="table-head">
        <div><h3>معايير التقويم</h3><p>عدّل قيمة كل معيار باستخدام أزرار الزيادة والنقصان.</p></div>
        <button className="ghost-btn" onClick={openEditor}><Icon name="edit"/> تعديل المعايير</button>
      </div>
      <div className="criteria-table">
        {criteria.map((c,i)=>
          <div className="criterion-line" key={c.name}>
            <div className={`criterion-icon ${c.color}`}>{c.icon}</div>
            <div className="criterion-main"><b>{c.name}</b><div className="progress"><i className={c.color} style={{width:(c.score/c.max*100)+'%'}}/></div></div>
            <div className="score-control">
              <button onClick={()=>changeScore(i,-0.5)}>−</button>
              <strong>{c.score}</strong>
              <button onClick={()=>changeScore(i,0.5)}>＋</button>
            </div>
            <span className={`score-label ${(c.score/c.max)>0.85?'good':(c.score/c.max)>0.7?'mid':'low'}`}>{(c.score/c.max)>0.85?'ممتاز':(c.score/c.max)>0.7?'جيد':'يحتاج متابعة'}</span>
            <small className="max-score">/{c.max}</small>
          </div>
        )}
      </div>
    </section>

    <section className="card section-preview-card">
      <div className="table-head">
        <div><h3>معاينة تقويم {selectedSection.name}</h3><p>راجع درجات التلاميذ وعدّل تقويم أي تلميذ قبل الطباعة أو التصدير.</p></div>
        <span className="preview-label">{students.length} تلميذاً</span>
      </div>
      <div className="section-preview-table">
        {students.length?students.map((student,index)=>{
          const values=studentScores[student]||criteria.map(item=>item.score);
          const totalStudent=values.reduce((sum,value)=>sum+Number(value||0),0);
          return (
            <div className="preview-student-row" key={student}>
              <span className="preview-number">{index+1}</span>
              <b>{student}</b>
              <span className="preview-score">{totalStudent.toFixed(1).replace('.0','')} / 20</span>
              <button className="ghost-btn" onClick={()=>setStudentEditor(student)}><Icon name="edit"/> تعديل</button>
            </div>
          );
        }):<div className="empty-preview">لا توجد أسماء محفوظة في هذا القسم بعد.</div>}
      </div>
    </section>

    {editing && (
      <div className="modal-backdrop" onClick={()=>setEditing(false)}>
        <div className="modal criteria-editor-modal" onClick={e=>e.stopPropagation()}>
          <button className="modal-close" onClick={()=>setEditing(false)}>×</button>
          <span className="eyebrow">إعدادات التقويم</span>
          <h2>تعديل المعايير</h2>
          <p>يمكنك تعديل اسم المعيار وحدّه الأقصى. يجب أن يساوي مجموع الحدود 20 نقطة.</p>
          <div className="criteria-edit-list">
            {draft.map((item,index)=>
              <div className="criteria-edit-row" key={index}>
                <div className={`criterion-icon ${item.color}`}>{item.icon}</div>
                <input className="criterion-name-input" value={item.name} onChange={e=>setDraft(items=>items.map((x,i)=>i===index?{...x,name:e.target.value}:x))}/>
                <label>الحد الأقصى<input type="number" min="0" step="0.5" value={item.max} onChange={e=>setDraft(items=>items.map((x,i)=>i===index?{...x,max:e.target.value}:x))}/></label>
              </div>
            )}
          </div>
          <div className={`criteria-total ${draft.reduce((sum,item)=>sum+Number(item.max||0),0)===20?'valid':''}`}>المجموع: <b>{draft.reduce((sum,item)=>sum+Number(item.max||0),0)}</b> / 20</div>
          <div className="criteria-editor-actions">
            <button className="outline-btn" onClick={()=>setEditing(false)}>إلغاء</button>
            <button className="primary-btn" onClick={saveEditor}><Icon name="check"/> حفظ التعديلات</button>
          </div>
        </div>
      </div>
    )}

    {studentEditor && (
      <div className="modal-backdrop" onClick={()=>setStudentEditor(null)}>
        <div className="modal student-assessment" onClick={e=>e.stopPropagation()}>
          <button className="modal-close" onClick={()=>setStudentEditor(null)}>×</button>
          <span className="eyebrow">تعديل تقويم التلميذ</span>
          <h2>{studentEditor}</h2>
          <p>يمكن تعديل كل معيار بمقدار 0.5 نقطة قبل التصدير.</p>
          <div className="personal-criteria">
            {criteria.map((criterion,index)=>
              <div className="personal-row" key={criterion.name}>
                <div className={`criterion-icon ${criterion.color}`}>{criterion.icon}</div>
                <div><b>{criterion.name}</b><small>من {criterion.max} نقاط</small></div>
                <div className="half-stepper">
                  <button onClick={()=>changeStudentScore(studentEditor,index,-0.5)}>−</button>
                  <strong>{Number(studentValues[index]||0).toFixed(1)}</strong>
                  <button onClick={()=>changeStudentScore(studentEditor,index,0.5)}>＋</button>
                </div>
              </div>
            )}
          </div>
          <div className="criteria-total valid">المجموع: <b>{studentTotal.toFixed(1)}</b> / 20</div>
          <button className="primary-btn modal-save" onClick={()=>{setStudentEditor(null);showToast('تم تحديث تقويم التلميذ')}}><Icon name="check"/> إغلاق وحفظ</button>
        </div>
      </div>
    )}
  </div>;
}