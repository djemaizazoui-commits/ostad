import { useState, useEffect } from 'react';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerTrigger } from '@/components/ui/drawer';
import Icon from './Icon';

/**
 * A select control that renders a native <select> on desktop (≥768px) and a
 * touch-friendly bottom-sheet drawer on mobile.
 *
 * `onChange` receives the option value (string), mirroring `e.target.value`.
 */
export default function MobileSelect({ value, onChange, children, className, label }) {
  const [isMobile, setIsMobile] = useState(
    typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches
  );
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(max-width: 767px)');
    const handler = (e) => setIsMobile(e.matches);
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  const options = Array.isArray(children) ? children : [children];
  const optionValue = (opt) => (opt.props.value !== undefined ? opt.props.value : opt.props.children);
  const selected = options.find((opt) => String(optionValue(opt)) === String(value));
  const selectedLabel = selected ? selected.props.children : 'اختر';

  if (!isMobile) {
    return (
      <select value={value} onChange={(e) => onChange(e.target.value)} className={className}>
        {children}
      </select>
    );
  }

  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <button type="button" className={`mobile-select-trigger ${className || ''}`}>
          <span>{selectedLabel}</span>
          <Icon name="arrow" />
        </button>
      </DrawerTrigger>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>{label || 'اختر'}</DrawerTitle>
        </DrawerHeader>
        <div className="mobile-select-list">
          {options.map((opt) => {
            const ov = optionValue(opt);
            const isActive = String(ov) === String(value);
            return (
              <button
                key={opt.key ?? String(ov)}
                type="button"
                className={`mobile-select-item ${isActive ? 'active' : ''}`}
                onClick={() => { onChange(ov); setOpen(false); }}
              >
                {opt.props.children}
                {isActive && <Icon name="check" />}
              </button>
            );
          })}
        </div>
      </DrawerContent>
    </Drawer>
  );
}