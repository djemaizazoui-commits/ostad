استيراد { cn } من "@/lib/utils"

function Skeleton({
  className,
 ... الديكورات
}) {
 العودة (
    (<div
      className={cn("animate-pulse rounded-md bg-primary/10", className)}
      {... الديكورات} />)
  );
}

export { Skeleton }