import { useEffect, useRef } from 'react';

/**
 * Pushes a browser history entry when a modal opens so the hardware/browser
 * back button dismisses the modal instead of leaving the app.
 *
 * @param {boolean} isOpen  Whether the modal is currently open.
 * @param {() => void} onClose  Callback to close the modal.
 */
export default function useModalHistory(isOpen, onClose) {
  const onCloseRef = useRef(onClose);
  const closedByPopRef = useRef(false);

  useEffect(() => { onCloseRef.current = onClose; });

  useEffect(() => {
    if (!isOpen) return;

    closedByPopRef.current = false;
    window.history.pushState({ bodoModal: true }, '');

    const onPop = () => {
      closedByPopRef.current = true;
      onCloseRef.current();
    };

    window.addEventListener('popstate', onPop);

    return () => {
      window.removeEventListener('popstate', onPop);
      // If the modal was closed explicitly (not via back button), pop the
      // history entry we pushed so the stack stays clean.
      if (!closedByPopRef.current && window.history.state && window.history.state.bodoModal) {
        window.history.back();
      }
    };
  }, [isOpen]);
}