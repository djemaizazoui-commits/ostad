import { base44 as db } from "@/api/base44Client";

import React, { useMemo, useState, useRef, useEffect } from 'react';
import * as XLSX from 'xlsx';
import Sidebar from '@/components/bodo/Sidebar';
import Topbar from '@/components/bodo/Topbar';
import Overview from '@/components/bodo/Overview';
import Seating from '@/components/bodo/Seating';
import Assessment from '@/components/bodo/Assessment';
import Gradebook from '@/components/bodo/Gradebook';
import SettingsPanel from '@/components/bodo/SettingsPanel';
import { initialStudents, criteriaSeed, middleLevels, defaultSections, defaultProfile, loadWorkspace, saveWorkspace } from '@/lib/bodoData';

import { AnimatePresence, motion } from 'framer-motion';
import PullToRefresh from '@/components/bodo/PullToRefresh';
import { useAuth } from '@/lib/AuthContext';

export default function Home(){
  const { user } = useAuth();
  const userId = user?.id || user?.email || 'local';
  const [active, setActive] = useState('overview');
  const [sections, setSections] = useState(defaultSections);
  const [selectedSectionId, setSelectedSectionId] = useState(1);
  const [selectedSectionIds, setSelectedSectionIds] = useState([1,2,3,4]);
  const [selectedLevelCodes, setSelectedLevelCodes] = useState(middleLevels.map(level=>level.code));
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [qualitySettings, setQualitySettings] = useState({autoSave:true,progressAlerts:true,compactLayout:false});
  const [attendanceMode, setAttendanceMode] = useState(false);
  const [attendanceBySection, setAttendanceBySection] = useState({});
  const [showSections, setShowSections] = useState(false);
  const [editingSection, setEditingSection] = useState(null);
  const [newSection, setNewSection] = useState({name:'',code:'',level:'الأولى متوسط',year:'2026 / 2027',subject:'الرياضيات'});
  const [studentsBySection, setStudentsBySection] = useState({1:initialStudents,2:[],3:[],4:[]});
  const [query, setQuery] = useState('');
  const [rows, setRows] = useState(3);
  const [cols, setCols] = useState(4);
  const [criteria, setCriteria] = useState(criteriaSeed);
  const [seatOrder, setSeatOrder] = useState(initialStudents);
  const [studentScores, setStudentScores] = useState(() => Object.fromEntries(initialStudents.map(name => [name, criteriaSeed.map(c => c.score)])));
  const [gradebookBySection, setGradebookBySection] = useState({});
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [toast, setToast] = useState('');
  const [profile, setProfile] = useState(defaultProfile);
  const [editingProfile, setEditingProfile] = useState(false);
  const [cloudSaving, setCloudSaving] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem('bodo-theme') || 'light');
  const fileInputRef = useRef(null);
  const sectionFileInputRef = useRef(null);
  const digitalFileInputRef = useRef(null);
  const syncFileInputRef = useRef(null);
  const dirtyRef = useRef(false);
  const mountedRef = useRef(false);
  const hydratedRef = useRef(false);
  const cloudRecordId = useRef(null);
  const cloudSaveTimer = useRef(null);
  const [pendingSectionStudents, setPendingSectionStudents] = useState([]);
  const selectedSection = sections.find(section=>section.id===selectedSectionId) || sections[0];
  const students = studentsBySection[selectedSectionId] || [];
  const visibleSections = useMemo(()=>sections.filter(section=>selectedSectionIds.includes(section.id)),[sections,selectedSectionIds]);

  // Apply theme class to document root
  useEffect(()=>{
    const root = document.documentElement;
    root.classList.remove('light','dark');
    root.classList.add(theme);
    localStorage.setItem('bodo-theme', theme);
  },[theme]);

  // Load workspace from cloud (fallback to localStorage)
  useEffect(()=>{
    hydratedRef.current = false;
    (async()=>{
      const local = loadWorkspace(userId);
      if(local) applyWorkspace(local);
      if(navigator.onLine === false){
        hydratedRef.current = true;
        return;
      }
      try{
        const records = await db.entities.BodoWorkspace.list('-updated_date', 1);
        if(records.length && records[0].data?.sections && records[0].data?.studentsBySection){
          cloudRecordId.current = records[0].id;
          const cloud = records[0].data;
          const localTime = local?.savedAt ? Date.parse(local.savedAt) : 0;
          const cloudTime = cloud?.savedAt ? Date.parse(cloud.savedAt) : 0;
          if(!local || cloudTime >= localTime) applyWorkspace(cloud);
          else await saveToCloud();
        }
      }catch(e){
        // Keep the local copy when cloud is unavailable.
      } finally {
        hydratedRef.current = true;
      }
    })();
  },[userId]);

  useEffect(()=>{
    const syncNow=()=>{ if(navigator.onLine) saveToCloud(); };
    window.addEventListener('online', syncNow);
    return ()=>window.removeEventListener('online', syncNow);
  },[userId]);

  // Auto-save to localStorage + debounced cloud save + track unsaved changes
  useEffect(()=>{
    if(!hydratedRef.current) return;
    saveWorkspace(syncPayload(), userId);
    if(mountedRef.current){
      dirtyRef.current=true;
      clearTimeout(cloudSaveTimer.current);
      cloudSaveTimer.current=setTimeout(()=>saveToCloud(),1500);
    } else { mountedRef.current=true; }
  },[profile,sections,studentsBySection,attendanceBySection,gradebookBySection,selectedSectionId,seatOrder,rows,cols,criteria,studentScores]);

  // Warn before closing/leaving when there are unsaved changes
  useEffect(()=>{
    const handler=(event)=>{ if(dirtyRef.current){ event.preventDefault(); event.returnValue=''; } };
    window.addEventListener('beforeunload', handler);
    return ()=>window.removeEventListener('beforeunload', handler);
  },[]);

  // Sync active tab with URL hash for hardware back button support
  useEffect(()=>{
    const valid=['overview','seating','assessment','gradebook'];
    const hash=window.location.hash.replace('#','');
    if(valid.includes(hash)) setActive(hash);
    else window.history.replaceState(null,'','#overview');
  },[]);

  useEffect(()=>{
    const onHashChange=()=>{
      const valid=['overview','seating','assessment','gradebook'];
      const hash=window.location.hash.replace('#','');
      if(valid.includes(hash)) setActive(hash);
    };
    window.addEventListener('hashchange',onHashChange);
    window.addEventListener('popstate',onHashChange);
    return ()=>{window.removeEventListener('hashchange',onHashChange);window.removeEventListener('popstate',onHashChange);};
  },[]);

  useEffect(()=>{
    if(window.location.hash!==`#${active}`) window.history.pushState(null,'',`#${active}`);
  },[active]);

  useEffect(()=>{setSeatOrder(students);},[selectedSectionId,studentsBySection]);
  useEffect(()=>{
    if(visibleSections.length && !visibleSections.some(section=>section.id===selectedSectionId)){
      const nextSection=visibleSections[0];
      setSelectedSectionId(nextSection.id);
      setProfile(prev=>({...prev,className:nextSection.name,year:nextSection.year,subject:nextSection.subject}));
    }
  },[visibleSections,selectedSectionId]);

  const visibleStudents = useMemo(()=>students.filter(s=>s.includes(query)), [students,query]);
  const showToast = (msg)=>{ setToast(msg); setTimeout(()=>setToast(''), 2200); };
  const syncPayload=()=>({version:1,app:'bodo',savedAt:new Date().toISOString(),profile,sections,studentsBySection,attendanceBySection,gradebookBySection,selectedSectionId,seatOrder,rows,cols,criteria,studentScores});
  const applyWorkspace=(data)=>{if(!data?.sections||!data?.studentsBySection)return; setProfile(data.profile||profile); setSections(data.sections); setStudentsBySection(data.studentsBySection); setAttendanceBySection(data.attendanceBySection||{}); setGradebookBySection(data.gradebookBySection||{}); setSelectedSectionIds(data.sections.map(section=>section.id)); const nextId=data.selectedSectionId||data.sections[0]?.id||1; setSelectedSectionId(nextId); setSeatOrder(data.seatOrder||data.studentsBySection[nextId]||[]); setRows(data.rows||3); setCols(data.cols||4); setCriteria(data.criteria||criteriaSeed); setStudentScores(data.studentScores||{});};

  const saveToCloud=async()=>{ if(navigator.onLine===false) return; try{ const payload=syncPayload(); if(cloudRecordId.current){ await db.entities.BodoWorkspace.update(cloudRecordId.current,{data:payload}); } else { const rec=await db.entities.BodoWorkspace.create({data:payload}); cloudRecordId.current=rec.id; } dirtyRef.current=false; }catch(e){} };
  const saveLocal=async()=>{setCloudSaving(true); saveWorkspace(syncPayload(), userId); clearTimeout(cloudSaveTimer.current); await saveToCloud(); setCloudSaving(false); showToast('تم الحفظ في السحابة');};
  const saveSyncFile=()=>{const payload=syncPayload(); const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const link=document.createElement('a'); link.href=url; link.download=`bodo-sync-${new Date().toISOString().slice(0,10)}.json`; link.click(); URL.revokeObjectURL(url); dirtyRef.current=false; showToast('تم حفظ ملف المزامنة — انقله إلى الجهاز الآخر');};
  const importSyncFile=(event)=>{const file=event.target.files?.[0]; if(!file)return; const reader=new FileReader(); reader.onload=()=>{try{const data=JSON.parse(String(reader.result)); if(data.app!=='bodo'||!data.sections||!data.studentsBySection)throw new Error('invalid'); applyWorkspace(data); dirtyRef.current=false; showToast('تم استيراد البيانات ومزامنة بودو بنجاح');}catch(error){showToast('ملف المزامنة غير صالح أو ليس من بودو');}}; reader.readAsText(file); event.target.value='';};
  const toggleAttendance=(student)=>{ setAttendanceBySection(current=>{const sectionAttendance={...(current[selectedSectionId]||{})}; const wasAbsent=sectionAttendance[student]==='absent'; sectionAttendance[student]=wasAbsent?'present':'absent'; return {...current,[selectedSectionId]:sectionAttendance};}); showToast(attendanceBySection[selectedSectionId]?.[student]==='absent'?'تم تسجيل حضور التلميذ':'تم تسجيل التلميذ غائباً'); };
  const seats = Array.from({length: rows*cols*2},(_,i)=>seatOrder[i] || null);
  const updateSection=(id,patch)=>setSections(items=>items.map(item=>item.id===id?{...item,...patch}:item));
  const addSection=()=>{ if(!newSection.name.trim()) return showToast('اكتب اسم القسم أولاً'); const sectionDraft={...newSection,name:newSection.name.trim(),code:newSection.name.trim(),subject:profile.subject||'الرياضيات'}; if(editingSection){updateSection(editingSection,sectionDraft); if(pendingSectionStudents.length)setStudentsBySection(all=>({...all,[editingSection]:pendingSectionStudents})); setSelectedSectionId(editingSection); setEditingSection(null); showToast('تم تعديل بيانات القسم');} else {const id=Date.now(); setSections(items=>[...items,{...sectionDraft,id}]); setSelectedSectionIds(current=>[...current,id]); setStudentsBySection(all=>({...all,[id]:pendingSectionStudents})); setSelectedSectionId(id); showToast(`تم حفظ القسم مع ${pendingSectionStudents.length} تلميذاً`);} setPendingSectionStudents([]); setNewSection({name:'',code:'',level:'الأولى متوسط',year:'2026 / 2027',subject:'الرياضيات'}); setShowSections(false); };

  const importDigitalSections=async(event)=>{const file=event.target.files?.[0]; if(!file)return; try{const data=await file.arrayBuffer(); const workbook=XLSX.read(data,{type:'array'}); const levelMap={'أولى':'الأولى متوسط','ثانية':'الثانية متوسط','ثالثة':'الثالثة متوسط','رابعة':'الرابعة متوسط'}; const levelCodeMap={'أولى':'1م','ثانية':'2م','ثالثة':'3م','رابعة':'4م'}; const imported=[]; const importedStudents={}; const importedGradebooks={}; let schoolName='',yearLabel='',subject=''; workbook.SheetNames.forEach((sheetName,sheetIndex)=>{const sheet=workbook.Sheets[sheetName]; const rowsData=XLSX.utils.sheet_to_json(sheet,{header:1,defval:''}); if(!rowsData.length)return; const flat=rowsData.flat().map(value=>String(value).trim()).filter(Boolean); if(!schoolName)schoolName=flat.find(value=>value.includes('متوسطة'))||''; const meta=flat.find(value=>value.includes('السنة الدراسية'))||''; const yearMatch=meta.match(/(20\d{2})\s*[-\/]\s*(20\d{2})/); if(yearMatch)yearLabel=`${yearMatch[1]} / ${yearMatch[2]}`; const subjectMatch=meta.match(/مادة\s*:\s*([^\s]+)/); if(subjectMatch)subject=subjectMatch[1]; const groupMatch=meta.match(/الفوج التربوي\s*:\s*(أولى|ثانية|ثالثة|رابعة)\s*متوسط\s*(\d+)/); if(!groupMatch)return; const levelLabel=levelMap[groupMatch[1]]; const sectionName=`${levelCodeMap[groupMatch[1]]}${groupMatch[2]}`; const headerIndex=rowsData.findIndex(row=>row.some(cell=>String(cell).trim().toLowerCase()==='matricule')); if(headerIndex<0)return; const header=rowsData[headerIndex].map(cell=>String(cell).trim().toLowerCase()); const find=(terms)=>header.findIndex(v=>terms.some(t=>v.includes(t))); const idx={matricule:find(['matricule','رقم التعريف']),nom:find(['nom','اللقب']),prenom:find(['prenom','الاسم']),date_n:find(['date_n','date','تاريخ']),activity:find(['01','نشاط','تقويم']),homework:find(['04','فرض']),exam:find(['09','اختبار','امتحان']),obs:find(['obs','تقدير','ملاحظ'])}; const records=rowsData.slice(headerIndex+1).map(row=>{const value=key=>idx[key]>=0?String(row[idx[key]]??'').trim():''; return {matricule:value('matricule'),nom:value('nom'),prenom:value('prenom'),date_n:value('date_n'),activity:value('activity'),homework:value('homework'),exam:value('exam'),obs:value('obs')};}).filter(row=>/^\d{8,}$/.test(row.matricule)||(row.nom&&row.prenom&&row.nom!=='اللقب'&&row.prenom!=='الاسم')); const id=Date.now()+sheetIndex; imported.push({id,name:sectionName,code:sectionName,level:levelLabel,year:yearLabel||profile.year,subject:subject||profile.subject}); importedStudents[id]=records.map(row=>`${row.nom} ${row.prenom}`.trim()); importedGradebooks[id]=records; }); if(!imported.length)return showToast('لم نجد أقساماً صالحة في ملف الرقمنة'); setSections(imported); setSelectedSectionIds(imported.map(section=>section.id)); setSelectedSectionId(imported[0].id); setStudentsBySection(importedStudents); setGradebookBySection(importedGradebooks); setProfile(prev=>({...prev,schoolName:schoolName||prev.schoolName,year:yearLabel||prev.year,subject:subject||prev.subject,className:imported[0].name})); showToast(`تم تحميل ${imported.length} أقسام مع قوائم التلاميذ وتوزيعها`);}catch(error){showToast('تعذر قراءة ملف الرقمنة، تأكد من صيغة XLSX')}finally{event.target.value='';}};

  const importSectionStudents=async(event)=>{ const file=event.target.files?.[0]; if(!file)return; try{ const data=await file.arrayBuffer(); const workbook=XLSX.read(data,{type:'array'}); const sheet=workbook.Sheets[workbook.SheetNames[0]]; const rowsData=XLSX.utils.sheet_to_json(sheet,{header:1,defval:''}); const values=rowsData.flat().map(value=>String(value).trim()).filter(Boolean); const names=[...new Set(values.filter(value=>!['الاسم','اسم التلميذ','التلميذ','name','student'].includes(value.toLowerCase())))]; if(!names.length)return showToast('لم نجد أسماء في ملف القسم'); setPendingSectionStudents(names); showToast(`تم تجهيز ${names.length} تلميذاً للقسم الجديد`); }catch(error){showToast('تعذر قراءة ملف XLSX للقسم')} finally{event.target.value='';} };
  const beginEditSection=(section)=>{setEditingSection(section.id);setNewSection({name:section.name,code:section.code,level:section.level||section.name,year:section.year,subject:section.subject});setPendingSectionStudents(studentsBySection[section.id]||[]);setShowSections(true);};
  const deleteSection=(id)=>{ if(sections.length<=1) return showToast('يجب الاحتفاظ بقسم واحد على الأقل'); const target=sections.find(section=>section.id===id); if(!target || !window.confirm(`هل تريد حذف قسم ${target.name}؟ سيتم حذف قائمة تلاميذه من هذه الجلسة.`)) return; const remaining=sections.filter(section=>section.id!==id); setSections(remaining); setSelectedSectionIds(current=>current.filter(sectionId=>sectionId!==id)); setStudentsBySection(all=>{const next={...all}; delete next[id]; return next;}); if(selectedSectionId===id){const nextSection=remaining[0]; setSelectedSectionId(nextSection.id); setProfile(prev=>({...prev,className:nextSection.name,year:nextSection.year,subject:nextSection.subject}));} setEditingSection(null); setPendingSectionStudents([]); setShowSections(false); showToast('تم حذف القسم'); };
  const importStudents=async(event)=>{ const file=event.target.files?.[0]; if(!file)return; try{ const data=await file.arrayBuffer(); const workbook=XLSX.read(data,{type:'array'}); const sheet=workbook.Sheets[workbook.SheetNames[0]]; const rowsData=XLSX.utils.sheet_to_json(sheet,{header:1,defval:''}); const values=rowsData.flat().map(value=>String(value).trim()).filter(Boolean); const names=values.filter(value=>!['الاسم','اسم التلميذ','التلميذ','name','student'].includes(value.toLowerCase())); const unique=[...new Set(names)]; if(!unique.length) return showToast('لم نجد أسماء في الملف'); setStudentsBySection(all=>({...all,[selectedSectionId]:unique})); setSeatOrder(unique); setStudentScores(Object.fromEntries(unique.map(name=>[name,criteriaSeed.map(c=>c.score)]))); showToast(`تم استيراد ${unique.length} تلميذاً من Excel`); }catch(error){ showToast('تعذر قراءة الملف، تأكد أنه XLSX صحيح'); } finally{event.target.value='';} };
  const downloadTemplate=()=>{ const sheet=XLSX.utils.aoa_to_sheet([['اسم التلميذ'],['أحمد بن علي'],['فاطمة بوعلام']]); const book=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book,sheet,'التلاميذ'); XLSX.writeFile(book,'bodo-students-template.xlsx'); showToast('تم تنزيل نموذج Excel'); };
  const changeScore=(index, delta)=>setCriteria(c=>c.map((item,i)=>i===index?{...item,score:Math.max(0,Math.min(item.max,item.score+delta))}:item));
  const addStudent=()=>{ if(newName.trim()){const name=newName.trim();setStudentsBySection(all=>({...all,[selectedSectionId]:[...(all[selectedSectionId]||[]),name]}));setSeatOrder(s=>[...s,name]);setStudentScores(s=>({...s,[name]:criteriaSeed.map(c=>c.score)}));setNewName('');setShowAdd(false);showToast('تمت إضافة التلميذ إلى القائمة');} };
  const changeStudentScore=(student,index,delta)=>setStudentScores(prev=>({...prev,[student]:(prev[student]||criteriaSeed.map(c=>c.score)).map((score,i)=>i===index?Math.max(0,Math.min(criteriaSeed[index].max,score+delta)):score)}));
  const printAssessment=()=>{showToast('استخدم خيار حفظ بصيغة PDF من نافذة الطباعة'); setTimeout(()=>window.print(),350)};
  const exportXlsx=()=>{const headers=['التلميذ',...criteria.map(item=>`${item.name} / ${item.max}`),'المجموع / 20']; const rows=students.map(name=>[name,...(studentScores[name]||criteria.map(item=>item.score)),criteria.reduce((sum,item)=>sum+item.score,0)]); const sheet=XLSX.utils.aoa_to_sheet([['بودو — تقويم القسم',selectedSection.name],['السنة الدراسية',selectedSection.year],[],headers,...rows]); const book=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book,sheet,'التقويم'); XLSX.writeFile(book,`تقويم-${selectedSection.code||selectedSection.name}.xlsx`); showToast('تم تصدير تقويم القسم إلى XLSX');};
  const exportWord=()=>{const rows=students.map(name=>`<tr><td>${name}</td>${(studentScores[name]||criteria.map(item=>item.score)).map((score,index)=>`<td>${score} / ${criteria[index].max}</td>`).join('')}<td>${criteria.reduce((sum,item,index)=>sum+(studentScores[name]?.[index]??item.score),0).toFixed(1)} / 20</td></tr>`).join(''); const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial;direction:rtl}h1{text-align:center;color:#4038a5}table{width:100%;border-collapse:collapse}th,td{border:1px solid #999;padding:8px;text-align:center}th{background:#eee}</style></head><body><h1>بودو — تقويم ${selectedSection.name}</h1><p>الأستاذ: ${profile.teacher} | المادة: ${selectedSection.subject} | السنة: ${selectedSection.year}</p><table><thead><tr><th>التلميذ</th>${criteria.map(item=>`<th>${item.name}<br>/${item.max}</th>`).join('')}<th>المجموع / 20</th></tr></thead><tbody>${rows}</tbody></table></body></html>`; const blob=new Blob([html],{type:'application/msword;charset=utf-8'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`تقويم-${selectedSection.code||selectedSection.name}.doc`; a.click(); URL.revokeObjectURL(url); showToast('تم تصدير ملف Word للقسم');};
  const printGradebook=()=>{showToast('اختر حفظ بصيغة PDF من نافذة الطباعة'); setTimeout(()=>window.print(),350)};
  const continuousAssessmentFor=(name)=>{const values=studentScores[name]||criteria.map(item=>item.score); return values.reduce((sum,value)=>sum+Number(value||0),0).toFixed(1).replace('.0','');};
  const gradebookRows=(gradebookBySection[selectedSectionId] || students.map((name,index)=>{const parts=name.split(' '); return {matricule:'',nom:parts[0]||name,prenom:parts.slice(1).join(' '),date_n:'',activity:'',homework:'',exam:'',obs:''};})).map(row=>({...row,activity:row.activity||continuousAssessmentFor(`${row.nom} ${row.prenom}`.trim())}));
  const importGradebook=async(event)=>{const file=event.target.files?.[0]; if(!file)return; try{const data=await file.arrayBuffer(); const workbook=XLSX.read(data,{type:'array'}); const parsed=[]; workbook.SheetNames.forEach(sheetName=>{const rowsData=XLSX.utils.sheet_to_json(workbook.Sheets[sheetName],{header:1,defval:''}); const headerIndex=rowsData.findIndex(row=>row.some(cell=>String(cell).toLowerCase().includes('matricule'))); if(headerIndex<0)return; const header=rowsData[headerIndex].map(cell=>String(cell).trim().toLowerCase()); const find=(terms)=>header.findIndex(v=>terms.some(t=>v.includes(t))); const idx={matricule:find(['matricule','رقم التعريف']),nom:find(['nom','اللقب']),prenom:find(['prenom','الاسم']),date_n:find(['date_n','date','تاريخ']),activity:find(['01','نشاط','تقويم']),homework:find(['04','فرض']),exam:find(['09','اختبار','امتحان']),obs:find(['obs','تقدير','ملاحظ'])}; const records=rowsData.slice(headerIndex+1).map(row=>{const value=(key)=>idx[key]>=0?String(row[idx[key]]??'').trim():''; return {matricule:value('matricule'),nom:value('nom'),prenom:value('prenom'),date_n:value('date_n'),activity:value('activity'),homework:value('homework'),exam:value('exam'),obs:value('obs')};}).filter(row=>row.nom||row.prenom); if(records.length)parsed.push({sheetName,records});}); if(!parsed.length)return showToast('لم نجد جداول نقاط صالحة في الملف'); setGradebookBySection(prev=>{const next={...prev}; parsed.forEach((item,index)=>{const targetSection=sections[index]?.id||selectedSectionId; next[targetSection]=item.records;}); return next;}); const activeImport=parsed[Math.min(parsed.findIndex(item=>item.records.length),0)]?.records||parsed[0].records; setStudentsBySection(prev=>({...prev,[selectedSectionId]:activeImport.map(row=>`${row.nom} ${row.prenom}`.trim())})); showToast(`تم استيراد ${parsed.reduce((sum,item)=>sum+item.records.length,0)} سجلاً من ${parsed.length} أوراق`);}catch(error){showToast('تعذر قراءة دفتر التنقيط، تأكد من ملف XLSX')}finally{event.target.value='';}};
  const exportGradebookXlsx=()=>{const rows=[['الجمهورية الجزائرية الديمقراطية الشعبية'],['وزارة التربية الوطنية'],[`${profile.schoolName} — دفتر التنقيط`],[`وثيقة حجز النقاط الخاصة بـ: ${selectedSection.name} | السنة الدراسية: ${selectedSection.year} | مادة: ${selectedSection.subject}`],[],['رقم التعريف','اللقب','الاسم','تاريخ الميلاد','معدل تقويم النشاطات /20','الفرض /20','الاختبار /20','التقديرات'],...gradebookRows.map(r=>[r.matricule,r.nom,r.prenom,r.date_n,r.activity,r.homework,r.exam,r.obs])]; const sheet=XLSX.utils.aoa_to_sheet(rows); sheet['!cols']=[{wch:22},{wch:18},{wch:22},{wch:15},{wch:22},{wch:12},{wch:14},{wch:28}]; const book=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book,sheet,selectedSection.code||'دفتر التنقيط'); XLSX.writeFile(book,`دفتر-التنقيط-${selectedSection.code||selectedSection.name}.xlsx`); showToast('تم تصدير دفتر التنقيط إلى XLSX');};
  const exportGradebookWord=()=>{const rows=gradebookRows.map(r=>`<tr><td>${r.matricule}</td><td>${r.nom}</td><td>${r.prenom}</td><td>${r.date_n}</td><td>${r.activity}</td><td>${r.homework}</td><td>${r.exam}</td><td>${r.obs}</td></tr>`).join(''); const html=`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>body{font-family:Arial;direction:rtl}h1,h2{text-align:center;color:#4038a5}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #777;padding:6px;text-align:center}th{background:#eeeefb}</style></head><body><h1>دفتر التنقيط</h1><h2>${profile.schoolName}</h2><p>القسم: ${selectedSection.name} — المادة: ${selectedSection.subject} — السنة: ${selectedSection.year}</p><table><thead><tr><th>رقم التعريف</th><th>اللقب</th><th>الاسم</th><th>تاريخ الميلاد</th><th>تقويم النشاطات /20</th><th>الفرض /20</th><th>الاختبار /20</th><th>التقديرات</th></tr></thead><tbody>${rows}</tbody></table></body></html>`; const blob=new Blob([html],{type:'application/msword;charset=utf-8'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`دفتر-التنقيط-${selectedSection.code||selectedSection.name}.doc`; a.click(); URL.revokeObjectURL(url); showToast('تم تصدير دفتر التنقيط إلى Word');};
  const syncContinuousAssessment=()=>{setGradebookBySection(prev=>({...prev,[selectedSectionId]:gradebookRows.map(row=>({...row,activity:continuousAssessmentFor(`${row.nom} ${row.prenom}`.trim())}))})); showToast('تم حفظ معدل التقويم المستمر في دفتر التنقيط');};

  return (
    <div className={`app-shell ${qualitySettings.compactLayout?'compact-layout':''}`}>
      <Sidebar active={active} setActive={setActive} profile={profile} students={students} onSettings={()=>setSettingsOpen(true)} showToast={showToast} />
      <main className="main-content">
        <Topbar active={active} attendanceMode={attendanceMode} setAttendanceMode={setAttendanceMode} setActive={setActive} showToast={showToast} saveSyncFile={saveSyncFile} importSyncFile={importSyncFile} syncFileInputRef={syncFileInputRef} saveLocal={saveLocal} cloudSaving={cloudSaving} theme={theme} setTheme={setTheme} />
        <PullToRefresh onRefresh={saveLocal}>
        <AnimatePresence mode="wait">
        {active==='overview' && (
          <motion.div key="overview" initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-24}} transition={{duration:0.25,ease:'easeOut'}}>
            <Overview profile={profile} setProfile={setProfile} editing={editingProfile} setEditing={setEditingProfile} students={students} setActive={setActive} showAdd={showAdd} setShowAdd={setShowAdd} newName={newName} setNewName={setNewName} addStudent={addStudent} visibleStudents={visibleStudents} query={query} setQuery={setQuery} showToast={showToast} criteria={criteria} sections={sections} visibleSections={visibleSections} levels={middleLevels} selectedLevelCodes={selectedLevelCodes} setSelectedLevelCodes={setSelectedLevelCodes} selectedSectionIds={selectedSectionIds} setSelectedSectionIds={setSelectedSectionIds} beginEditSection={beginEditSection} deleteSection={deleteSection} selectedSection={selectedSection} selectedSectionId={selectedSectionId} setSelectedSectionId={setSelectedSectionId} showSections={showSections} setShowSections={setShowSections} editingSection={editingSection} setEditingSection={setEditingSection} updateSection={updateSection} newSection={newSection} setNewSection={setNewSection} addSection={addSection} importStudents={importStudents} downloadTemplate={downloadTemplate} fileInputRef={fileInputRef} sectionFileInputRef={sectionFileInputRef} pendingSectionStudents={pendingSectionStudents} setPendingSectionStudents={setPendingSectionStudents} importSectionStudents={importSectionStudents} digitalFileInputRef={digitalFileInputRef} importDigitalSections={importDigitalSections} />
          </motion.div>
        )}
        {active==='seating' && (
          <motion.div key="seating" initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-24}} transition={{duration:0.25,ease:'easeOut'}}>
            <Seating sections={sections} setSelectedSectionId={setSelectedSectionId} profile={profile} selectedSection={selectedSection} rows={rows} cols={cols} setRows={setRows} setCols={setCols} seats={seats} students={students} seatOrder={seatOrder} setSeatOrder={setSeatOrder} studentScores={studentScores} changeStudentScore={changeStudentScore} showToast={showToast} attendanceMode={attendanceMode} selectedSectionId={selectedSectionId} attendanceBySection={attendanceBySection} toggleAttendance={toggleAttendance} />
          </motion.div>
        )}
        {active==='assessment' && (
          <motion.div key="assessment" initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-24}} transition={{duration:0.25,ease:'easeOut'}}>
            <Assessment criteria={criteria} setCriteria={setCriteria} changeScore={changeScore} changeStudentScore={changeStudentScore} exportXlsx={exportXlsx} exportWord={exportWord} printAssessment={printAssessment} showToast={showToast} students={students} selectedSection={selectedSection} sections={sections} selectedSectionId={selectedSectionId} setSelectedSectionId={setSelectedSectionId} studentScores={studentScores} studentsBySection={studentsBySection} />
          </motion.div>
        )}
        {active==='gradebook' && (
          <motion.div key="gradebook" initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-24}} transition={{duration:0.25,ease:'easeOut'}}>
            <Gradebook rows={gradebookRows} sections={sections} selectedSection={selectedSection} selectedSectionId={selectedSectionId} setSelectedSectionId={setSelectedSectionId} importGradebook={importGradebook} exportGradebookXlsx={exportGradebookXlsx} exportGradebookWord={exportGradebookWord} printGradebook={printGradebook} syncContinuousAssessment={syncContinuousAssessment} setGradebookBySection={setGradebookBySection} showToast={showToast} />
          </motion.div>
        )}
        </AnimatePresence>
        </PullToRefresh>
      </main>
      {settingsOpen && <SettingsPanel settings={qualitySettings} setSettings={setQualitySettings} onClose={()=>setSettingsOpen(false)} />}
      {toast && <div className="toast"><span>✓</span>{toast}</div>}
    </div>
  );
}